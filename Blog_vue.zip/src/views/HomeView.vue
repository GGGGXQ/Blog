
<template>
  <main class="min-h-screen flex items-center justify-center bg-cover bg-no-repeat bg-center">
  
  </main>
</template>
